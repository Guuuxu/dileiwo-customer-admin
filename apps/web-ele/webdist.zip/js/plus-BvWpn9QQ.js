import{i as e}from"./bootstrap-Ctc4KYZB.js";const a=e("PlusIcon",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);export{a as P};
